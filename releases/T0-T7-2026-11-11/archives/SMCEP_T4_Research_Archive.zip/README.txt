SMCEP T4 RESEARCH ARCHIVE
Date: 2026-11-10

Contents:
- drive_t4/: 40 original T4 files
- vm_evaluations/: 10 sandbox evaluation records
- reference/: T3 inherited baseline procedure
- SHA256_MANIFEST.json: integrity information

The three-cycle T4 behavioral experiment is completed.

IMPORTANT LIMITATION:
The original T4 protocol and methodology addendum were not found
in the inspected Google Drive directory. They have not been
recreated, inferred, or represented as original documents.

The original files and VM records were not modified.
The archive does not itself contain the VM sandbox runner or
a complete executable environment specification.

Cycle 1 budget control is post-hoc exploratory.
