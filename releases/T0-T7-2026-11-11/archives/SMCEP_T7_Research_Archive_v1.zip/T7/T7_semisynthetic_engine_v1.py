
import hashlib
import math
import random

ARMS = ("frozen", "linear", "hybrid", "hybrid_ablation")

def clip(x):
    return max(0.0, min(1.0, x))

def stream(seed, generation, attempt, channel):
    """Deterministic, arm-independent random stream."""
    key = f"{seed}:{generation}:{attempt}:{channel}"
    digest = hashlib.sha256(key.encode()).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))

def initial_state():
    return {
        "quality": [0.35] * 4,
        "meta": 0.20,
        "archive": [],
        "accepted": 0,
        "attempts": 0
    }

def fresh_candidate(seed, generation, attempt, state, params):
    r = stream(seed, generation, attempt, "candidate")
    domain = (generation + attempt) % 4

    strength = clip(
        0.5 + r.gauss(0, params["innovation_noise_sd"])
    )

    return {
        "domain": domain,
        "strength": strength,
        "origin": "fresh",
        "source_generation": generation
    }

def step(state, arm, seed, generation, params, scenario):
    assert arm in ARMS

    s = {
        "quality": list(state["quality"]),
        "meta": state["meta"],
        "archive": [dict(x) for x in state["archive"]],
        "accepted": state["accepted"],
        "attempts": state["attempts"]
    }

    if arm == "frozen":
        return s

    # Metacapacity decay is independent of task performance.
    s["meta"] = clip(
        s["meta"] - params["meta_decay_per_generation"]
    )

    for attempt in range(params["candidate_attempts"]):
        fresh = fresh_candidate(
            seed, generation, attempt, s, params
        )
        candidate = fresh
        reused = False

        # Only Hybrid can draw from the persistent archive.
        # One opportunity remains one opportunity.
        if arm == "hybrid" and attempt == 0:
            matching = [
                x for x in s["archive"]
                if x["domain"] == fresh["domain"]
            ]
            if matching:
                candidate = max(
                    matching,
                    key=lambda x: (
                        x["strength"],
                        -x["source_generation"]
                    )
                )
                reused = True

        domain = candidate["domain"]

        probability = clip(
            params["base_improvement_probability"]
            + params["meta_skill_probability_coefficient"] * s["meta"]
            + (
                scenario["archive_reuse_effect"]
                if reused else 0.0
            )
        )

        u = stream(
            seed, generation, attempt, "success"
        ).random()

        gross_gain = (
            params["performance_gain_max"]
            * candidate["strength"]
            * (1.0 - s["quality"][domain])
        )

        net_gain = gross_gain - (
            scenario["archive_cost"] if reused else 0.0
        )

        accepted = u < probability and net_gain > 0.0

        s["attempts"] += 1

        if accepted:
            s["quality"][domain] = clip(
                s["quality"][domain] + net_gain
            )
            s["accepted"] += 1

            # A successful task improvement does NOT
            # automatically improve metacapacity.
            meta_rng = stream(
                seed, generation, attempt, "meta_event"
            )
            if meta_rng.random() < params["meta_gain_probability"]:
                s["meta"] = clip(
                    s["meta"]
                    + params["meta_gain_max"]
                    * meta_rng.random()
                )

        elif arm == "hybrid" and not reused:
            s["archive"].append(dict(fresh))
            s["archive"] = sorted(
                s["archive"],
                key=lambda x: (
                    -x["strength"],
                    x["source_generation"],
                    x["domain"]
                )
            )[:params["archive_capacity"]]

    return s

def measured_C(state, seed, generation, params, probes=30):
    """Fresh, non-persistent improvement opportunities."""
    successes = 0
    p = clip(
        params["base_improvement_probability"]
        + params["meta_skill_probability_coefficient"]
        * state["meta"]
    )

    for i in range(probes):
        u = stream(
            seed, generation, i, "capacity_probe"
        ).random()
        successes += (u < p)

    return successes / probes

def performance(state):
    return sum(state["quality"]) / len(state["quality"])

def validate_state(state, params):
    assert len(state["quality"]) == 4
    assert all(0 <= q <= 1 for q in state["quality"])
    assert 0 <= state["meta"] <= 1
    assert len(state["archive"]) <= params["archive_capacity"]
    assert state["accepted"] <= state["attempts"]

def self_test(params):
    scenario = {
        "archive_reuse_effect": 0.0,
        "archive_cost": 0.0
    }

    states = {arm: initial_state() for arm in ARMS}

    for generation in range(1, 6):
        for arm in ARMS:
            states[arm] = step(
                states[arm], arm, 700001,
                generation, params, scenario
            )
            validate_state(states[arm], params)

    assert states["frozen"] == initial_state()

    # Under this specification, ablation and Linear
    # are intentionally equivalent controls.
    assert states["linear"] == states["hybrid_ablation"]

    for arm in ARMS:
        assert states[arm]["attempts"] == (
            0 if arm == "frozen" else
            5 * params["candidate_attempts"]
        )

        c = measured_C(states[arm], 700001, 5, params)
        assert 0 <= c <= 1
        assert 0 <= performance(states[arm]) <= 1

    return {
        arm: {
            "P5": round(performance(s), 6),
            "C5_probe": round(
                measured_C(s, 700001, 5, params), 6
            ),
            "meta5": round(s["meta"], 6),
            "accepted": s["accepted"],
            "archive_size": len(s["archive"]),
            "attempts": s["attempts"]
        }
        for arm, s in states.items()
    }
