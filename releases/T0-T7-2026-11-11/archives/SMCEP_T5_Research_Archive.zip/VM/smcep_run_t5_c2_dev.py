import json, base64, subprocess, sys, ast
from smcep_t3_result_handler import save_results

p = json.load(open("/home/otakkonya/t5_cycle_2_development_test_package_v1.json"))
records = p["solutions"]

results = []
for k, r in enumerate(records, 1):
    if r["source"] is None:
        for i in range(1, len(r["tests"]) + 1):
            results.append({"task_id": r["task_id"], "condition": r["condition"], "test_index": i, "status": r.get("normalization_status", "NORMALIZATION_ERROR")})
        print("NORMALIZATION_ERROR", r["task_id"], r["condition"], flush=True)
        continue
    tree = ast.parse(r["source"])
    allowed = (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
    r = dict(r, source=ast.unparse(ast.Module(body=[n for n in tree.body if isinstance(n, allowed)], type_ignores=[])))
    payload = base64.b64encode(json.dumps(r).encode()).decode()
    script = (
        "import json,base64\n"
        "r=json.loads(base64.b64decode(" + repr(payload) + "))\n"
        "n={}\n"
        "exec(r['source'],n)\n"
        "f=n[r['function']]\n"
        "for i,t in enumerate(r['tests'],1):\n"
        " try:\n"
        "  actual=f(*t['args'])\n"
        "  print('SMCEP_RESULT',r['task_id'],r['condition'],i,"
        "'PASS' if actual==t['expected'] else 'FAIL',flush=True)\n"
        " except Exception as e:\n"
        "  print('SMCEP_RESULT',r['task_id'],r['condition'],i,"
        "'ERROR',type(e).__name__,flush=True)\n"
    )
    unit = "smcep-t5-c2-dev-%02d" % k
    cmd = [
        "sudo", "systemd-run", "--unit=" + unit,
        "--property=Type=exec", "--property=RuntimeMaxSec=10s",
        "--property=MemoryMax=128M", "--property=MemorySwapMax=0",
        "--property=TasksMax=16", "--property=CPUQuota=50%",
        "--wait", "--collect",
        "/usr/sbin/runuser", "-u", "otakkonya", "--",
        "/usr/bin/bwrap", "--unshare-all", "--new-session",
        "--die-with-parent", "--cap-drop", "ALL",
        "--ro-bind", "/usr", "/usr",
        "--ro-bind", "/lib", "/lib",
        "--ro-bind", "/lib64", "/lib64",
        "--size", "16777216", "--tmpfs", "/tmp",
        "--proc", "/proc", "--dev", "/dev", "--chdir", "/tmp",
        "/usr/bin/python3", "-I", "-S", "-c", script
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode:
        print("SANDBOX_ERROR", r["task_id"], r["condition"])
        results.extend({"task_id": r["task_id"], "condition": r["condition"], "test_index": i, "status": "SANDBOX_ERROR"} for i in range(1, len(r["tests"]) + 1))
        print(result.stderr[-500:])
        continue
    log = subprocess.run(
        ["sudo", "journalctl", "-u", unit + ".service",
         "--no-pager", "-o", "cat"],
        capture_output=True, text=True
    )
    for line in log.stdout.splitlines():
        if line.startswith("SMCEP_RESULT "):
            print(line, flush=True)
            parts = line.split()
            results.append({"task_id": parts[1], "condition": parts[2], "test_index": int(parts[3]), "status": parts[4], "error_type": parts[5] if len(parts) > 5 else None})

save_results(results, "/home/otakkonya/t5_cycle_2_development_evaluation_v1.json")
print("T3_RECORDED", len(results), flush=True)
