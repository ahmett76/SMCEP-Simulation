
import sqlite3
import json
import subprocess
from pathlib import Path
from google.colab import userdata

ROOT = Path("/content/drive/MyDrive/SMCEP_Real_LLM")
DB = ROOT / "SMCEP_T6_v1_3_Pilot.sqlite"

PROJECT = "project-2c8c8554-050d-4df9-916"
ZONE = "us-central1-c"
VM = "smcep-audit-vm-01"
USER = "otakkonya"

def vm_command(command, timeout=60):
    args = [
        "gcloud", "compute", "ssh",
        f"{USER}@{VM}",
        f"--project={PROJECT}",
        f"--zone={ZONE}",
        "--tunnel-through-iap",
        "--quiet",
        "--ssh-flag=-o BatchMode=yes",
        "--command=" + command
    ]
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=timeout
    )

def preflight():
    assert DB.is_file(), "T6 database missing"

    with sqlite3.connect(DB) as conn:
        settings = {
            key: json.loads(value)
            for key, value in conn.execute(
                "SELECT key,value FROM protocol"
            )
        }

        candidate_count = conn.execute(
            "SELECT COUNT(*) FROM candidates"
        ).fetchone()[0]

    assert candidate_count == 0, "Pilot already has candidates"
    assert settings["pilot_settings"]["execution_started"] is False
    assert settings["pilot_operations"]["status"] == "DRAFT"
    assert settings["measurement_protocol"]["status"] == "DRAFT"

    assert userdata.get("GROQ_API_KEY"), "Groq key unavailable"

    result = vm_command(
        "command -v bwrap >/dev/null && "
        "command -v systemd-run >/dev/null && "
        "echo T6_VM_READY"
    )

    assert result.returncode == 0, (
        "VM connection failed: " + result.stderr[-500:]
    )
    assert "T6_VM_READY" in result.stdout

    print("T6_RUNNER_PREFLIGHT_OK")
    print("DATABASE:", DB.name)
    print("ARMS:", settings["pilot_settings"]["arms"])
    print("ROUNDS:", settings["pilot_settings"]["rounds"])
    print("VM:", VM)
    print("PROTOCOL:", "DRAFT")
    print("EXECUTION_STARTED:", False)

if __name__ == "__main__":
    preflight()



# T6_TASK_BANK_V1
# Trusted experiment definitions. No model-generated code is executed here.

TASK_BANK = {
    "development": [
        {
            "id": "dev_dedupe",
            "function": "dedupe_stable",
            "spec": (
                "Write dedupe_stable(items). Return a list containing "
                "the first occurrence of each integer, preserving order. "
                "Input is a list of integers. Do not modify the input."
            ),
            "tests": [
                {"args": [[1, 2, 1, 3]], "expected": [1, 2, 3]},
                {"args": [[]], "expected": []},
                {"args": [[4, 4, 4]], "expected": [4]},
                {"args": [[-1, 0, -1]], "expected": [-1, 0]},
                {"args": [[3, 2, 1]], "expected": [3, 2, 1]}
            ]
        },
        {
            "id": "dev_window",
            "function": "window_sums",
            "spec": (
                "Write window_sums(values, k). Return sums of all "
                "contiguous windows of length k. Values are integers; "
                "k is a positive integer. If k exceeds list length, "
                "return an empty list."
            ),
            "tests": [
                {"args": [[1, 2, 3], 2], "expected": [3, 5]},
                {"args": [[5], 1], "expected": [5]},
                {"args": [[], 1], "expected": []},
                {"args": [[2, -2, 4], 3], "expected": [4]},
                {"args": [[1, 2], 3], "expected": []}
            ]
        }
    ],
    "selection": [
        {
            "id": "sel_groups",
            "function": "group_consecutive",
            "spec": (
                "Write group_consecutive(values). Given a list of "
                "integers, return a list of lists grouping adjacent "
                "equal values. Preserve the original order."
            ),
            "tests": [
                {"args": [[1, 1, 2, 2, 1]],
                 "expected": [[1, 1], [2, 2], [1]]},
                {"args": [[]], "expected": []},
                {"args": [[3]], "expected": [[3]]},
                {"args": [[1, 2, 3]],
                 "expected": [[1], [2], [3]]},
                {"args": [[0, 0, 0]], "expected": [[0, 0, 0]]}
            ]
        },
        {
            "id": "sel_interleave",
            "function": "interleave_lists",
            "spec": (
                "Write interleave_lists(a, b). Alternate elements "
                "from lists a and b, beginning with a. When one list "
                "ends, append the remaining elements of the other."
            ),
            "tests": [
                {"args": [[1, 2], [3, 4]], "expected": [1, 3, 2, 4]},
                {"args": [[], [5]], "expected": [5]},
                {"args": [[1], []], "expected": [1]},
                {"args": [[1, 2, 3], [9]], "expected": [1, 9, 2, 3]},
                {"args": [[], []], "expected": []}
            ]
        }
    ],
    "metacapacity": [
        {
            "id": "meta_merge",
            "function": "merge_sorted_unique",
            "spec": (
                "Write merge_sorted_unique(a, b). Given two sorted "
                "integer lists, return their sorted union without "
                "duplicates. Do not mutate the arguments."
            ),
            "tests": [
                {"args": [[1, 3], [2, 3]], "expected": [1, 2, 3]},
                {"args": [[], []], "expected": []},
                {"args": [[1, 1], []], "expected": [1]},
                {"args": [[-2, 0], [-1, 0]], "expected": [-2, -1, 0]},
                {"args": [[4], [4]], "expected": [4]}
            ]
        },
        {
            "id": "meta_ranges",
            "function": "compress_runs",
            "spec": (
                "Write compress_runs(values). Given a strictly "
                "increasing list of integers, return consecutive "
                "runs as lists [start, end]. Singletons become [x, x]."
            ),
            "tests": [
                {"args": [[1, 2, 3, 5]], "expected": [[1, 3], [5, 5]]},
                {"args": [[]], "expected": []},
                {"args": [[7]], "expected": [[7, 7]]},
                {"args": [[-2, -1, 1]], "expected": [[-2, -1], [1, 1]]},
                {"args": [[1, 3, 5]],
                 "expected": [[1, 1], [3, 3], [5, 5]]}
            ]
        }
    ]
}

def validate_task_bank():
    ids = []
    for partition, tasks in TASK_BANK.items():
        assert len(tasks) == 2
        for task in tasks:
            ids.append(task["id"])
            assert len(task["tests"]) == 5
            assert task["function"] in task["spec"]
            assert all(
                "args" in test and "expected" in test
                for test in task["tests"]
            )
    assert len(ids) == len(set(ids))
    return {
        partition: sum(len(t["tests"]) for t in tasks)
        for partition, tasks in TASK_BANK.items()
    }



# T6_GROQ_ENGINE_V1
# Generation only. Never execute model-generated Python in Colab.

import requests
import time

GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"
T6_MODEL = "openai/gpt-oss-20b"

T6_GENERATION = {
    "temperature": 0,
    "max_completion_tokens": 384,
    "reasoning_effort": "low",
    "include_reasoning": False,
    "tool_choice": "none"
}

def groq_generate(messages, request_kind):
    assert request_kind in ("code", "revision")

    # T6_V1_1_TOKEN_POLICY
    # Sequential execution only; choose budget for each request.
    T6_GENERATION["max_completion_tokens"] = (
        1024 if request_kind == "code" else 384
    )

    key = userdata.get("GROQ_API_KEY")
    assert key, "Groq API key missing"

    payload = {
        "model": T6_MODEL,
        "messages": messages,
        **T6_GENERATION
    }

    started = time.monotonic()

    try:
        response = requests.post(
            GROQ_ENDPOINT,
            headers={"Authorization": "Bearer " + key},
            json=payload,
            timeout=90
        )
    except requests.RequestException as exc:
        raise RuntimeError(
            "API_TRANSPORT_FAILURE: " + type(exc).__name__
        ) from None

    elapsed = round(time.monotonic() - started, 3)

    if not response.ok:
        try:
            error_obj = response.json().get("error", {})
            error_type = str(error_obj.get("type", "UNKNOWN"))
            error_code = str(error_obj.get("code", "UNKNOWN"))
            error_message = str(error_obj.get("message", ""))

            # Only an allowlisted error classification is recorded.
            known = (
                "tool_use_failed",
                "invalid_request_error",
                "rate_limit_exceeded",
                "context_length_exceeded"
            )

            classification = next(
                (item for item in known
                 if item in (error_type + " " + error_code
                             + " " + error_message).lower()),
                "OTHER_API_ERROR"
            )

        except (ValueError, AttributeError, TypeError):
            classification = "UNPARSEABLE_API_ERROR"

        raise RuntimeError(
            "API_DELIVERY_FAILED_HTTP_"
            + str(response.status_code)
            + "_"
            + classification
        )

    data = response.json()
    choice = data["choices"][0]
    usage = data.get("usage", {})

    content = choice["message"].get("content") or ""

    return {
        "kind": request_kind,
        "content": content,
        "finish_reason": choice.get("finish_reason"),
        "prompt_tokens": usage.get("prompt_tokens"),
        "completion_tokens": usage.get("completion_tokens"),
        "total_tokens": usage.get("total_tokens"),
        "duration_seconds": elapsed,
        "content_sha256": hashlib.sha256(
            content.encode("utf-8")
        ).hexdigest()
    }


def generate_task_solution(task, procedure=None):
    assert task["spec"]
    assert task["function"]

    system = (
        "You are a Python coding assistant. "
        "Write executable Python source code directly in your final assistant message. "
        "Do not call or invoke any tools, functions, code interpreters, "
        "or external execution environments. "
        "Do not request tool execution. "
        "Return only Python source code. "
        "No Markdown, explanations, or example calls."
    )

    if procedure is not None:
        system += (
            "\nFollow this reusable development procedure:\n"
            + procedure
        )

    return groq_generate(
        [
            {"role": "system", "content": system},
            {"role": "user", "content": task["spec"]}
        ],
        request_kind="code"
    )


def generate_procedure_revision(
    current_procedure,
    development_feedback,
    archive_context=None
):
    system = (
        "You improve a reusable Python coding procedure. "
        "Write the complete revised procedure directly in your "
        "final assistant message. "
        "Do not call or invoke any tools, functions, code interpreters, "
        "or external execution environments. "
        "Do not request tool execution. "
        "Return only a concise five-step procedure. "
        "Do not output Python code. "
        "Prefer generalizable improvements over task-specific tricks."
    )

    user_message = (
        "Current procedure:\n"
        + current_procedure
        + "\n\nDevelopment feedback:\n"
        + json.dumps(development_feedback, ensure_ascii=False)
    )

    if archive_context:
        user_message += (
            "\n\nPrevious candidate insights:\n"
            + json.dumps(archive_context, ensure_ascii=False)
        )

    user_message += (
        "\n\nSuggest a reusable improvement. "
        "Do not claim it works without independent testing."
    )

    return groq_generate(
        [
            {"role": "system", "content": system},
            {"role": "user", "content": user_message}
        ],
        request_kind="revision"
    )



# T6_SANDBOX_CLIENT_V1
# Model-generated Python is executed only inside the isolated VM.

import base64
import shlex

T6_EVALUATOR_SHA256 = (
    "49bb15bb36ef9fd377a9d1ef73da87a0bd09fa67bc261e9f38e346d2fb2e5e6c"
)

def evaluate_solution(task, source):
    assert isinstance(source, str)
    assert isinstance(task, dict)
    assert 0 < len(source) <= 30000

    record = {
        "source": source,
        "function": task["function"],
        "tests": task["tests"]
    }

    encoded = base64.b64encode(
        json.dumps(record).encode("utf-8")
    ).decode("ascii")

    command = (
        "python3 ~/t6_vm_evaluator.py "
        + shlex.quote(encoded)
    )

    result = vm_command(command, timeout=90)

    if result.returncode != 0:
        return {
            "status": "VM_TRANSPORT_ERROR",
            "results": [],
            "expected_tests": len(task["tests"]),
            "transport_returncode": result.returncode,
            "diagnostic": result.stderr[-500:]
        }

    prefix = "T6_EVALUATION_JSON:"

    matches = [
        line[len(prefix):]
        for line in result.stdout.splitlines()
        if line.startswith(prefix)
    ]

    if len(matches) != 1:
        return {
            "status": "EVALUATION_RESPONSE_ERROR",
            "results": [],
            "expected_tests": len(task["tests"])
        }

    evaluation = json.loads(matches[0])

    expected_count = len(task["tests"])
    observed = evaluation.get("results", [])

    valid_indices = [
        r.get("test_index") for r in observed
    ]

    if (
        len(observed) != expected_count
        or sorted(valid_indices) != list(
            range(1, expected_count + 1)
        )
    ):
        if evaluation.get("status") == "COMPLETED":
            evaluation["status"] = "INCOMPLETE_RESULTS"

    evaluation["task_id"] = task["id"]
    evaluation["source_sha256"] = hashlib.sha256(
        source.encode("utf-8")
    ).hexdigest()

    return evaluation



# T6_SQLITE_RECORDER_V1
# Append-only experiment event and candidate recording.

import hashlib

VALID_ARMS = ("frozen", "linear", "hybrid")
VALID_PARTITIONS = ("development", "selection", "metacapacity")

def canonical_json(obj):
    return json.dumps(
        obj, sort_keys=True, ensure_ascii=False,
        separators=(",", ":"), allow_nan=False
    )

def append_event(conn, event_type, payload, arm=None, round_number=None):
    encoded = canonical_json(payload)
    digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()

    cursor = conn.execute("""
        INSERT INTO events(
            arm, round_number, event_type,
            payload_json, payload_sha256
        ) VALUES (?, ?, ?, ?, ?)
    """, (
        arm, round_number, event_type, encoded, digest
    ))

    return cursor.lastrowid


def record_generation(
    arm, round_number, response,
    parent_id=None, candidate_kind="procedure"
):
    assert arm in VALID_ARMS
    assert 0 <= round_number <= 10
    assert candidate_kind in ("procedure", "code")

    source = response["content"]
    assert isinstance(source, str) and source.strip()

    source_sha = hashlib.sha256(
        source.encode("utf-8")
    ).hexdigest()

    with sqlite3.connect(DB) as conn:
        conn.execute("PRAGMA foreign_keys=ON")

        if parent_id is not None:
            parent = conn.execute(
                "SELECT arm FROM candidates WHERE id=?",
                (parent_id,)
            ).fetchone()
            assert parent is not None
            assert parent[0] == arm

        with conn:
            cursor = conn.execute("""
                INSERT INTO candidates(
                    arm, round_number, parent_id,
                    source_text, source_sha256,
                    tokens, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                arm, round_number, parent_id,
                source, source_sha,
                response.get("total_tokens"),
                "GENERATED_" + candidate_kind.upper()
            ))

            candidate_id = cursor.lastrowid

            append_event(
                conn,
                "CANDIDATE_GENERATED",
                {
                    "candidate_id": candidate_id,
                    "candidate_kind": candidate_kind,
                    "source_sha256": source_sha,
                    "finish_reason": response.get("finish_reason"),
                    "prompt_tokens": response.get("prompt_tokens"),
                    "completion_tokens": response.get("completion_tokens"),
                    "total_tokens": response.get("total_tokens"),
                    "duration_seconds": response.get("duration_seconds")
                },
                arm,
                round_number
            )

    return candidate_id


def record_evaluation(
    candidate_id, partition, task_id, evaluation
):
    assert partition in VALID_PARTITIONS
    assert isinstance(task_id, str) and task_id
    assert isinstance(evaluation, dict)

    expected_tests = evaluation.get("expected_tests")
    results = evaluation.get("results", [])

    assert isinstance(expected_tests, int)
    assert 1 <= expected_tests <= 20
    assert isinstance(results, list)

    if evaluation.get("status") == "COMPLETED":
        assert len(results) == expected_tests
        assert sorted(
            r["test_index"] for r in results
        ) == list(range(1, expected_tests + 1))

    passed = sum(
        r.get("status") == "PASS"
        for r in results
    )

    # Missing evaluations must never be scored as model failures.
    score = (
        passed / expected_tests
        if evaluation.get("status") == "COMPLETED"
        else None
    )

    details = canonical_json(evaluation)

    with sqlite3.connect(DB) as conn:
        conn.execute("PRAGMA foreign_keys=ON")

        candidate = conn.execute("""
            SELECT arm, round_number
            FROM candidates WHERE id=?
        """, (candidate_id,)).fetchone()

        assert candidate is not None
        arm, round_number = candidate

        # Prevent accidentally recording the same evaluation twice.
        duplicate = conn.execute("""
            SELECT COUNT(*) FROM evaluations
            WHERE candidate_id=? AND partition=? AND task_id=?
        """, (
            candidate_id, partition, task_id
        )).fetchone()[0]

        assert duplicate == 0, "Evaluation already recorded"

        with conn:
            cursor = conn.execute("""
                INSERT INTO evaluations(
                    candidate_id, partition, task_id,
                    status, score, details_json
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                candidate_id, partition, task_id,
                evaluation["status"], score, details
            ))

            evaluation_id = cursor.lastrowid

            append_event(
                conn,
                "EVALUATION_RECORDED",
                {
                    "evaluation_id": evaluation_id,
                    "candidate_id": candidate_id,
                    "partition": partition,
                    "task_id": task_id,
                    "status": evaluation["status"],
                    "passed": passed,
                    "expected_tests": expected_tests,
                    "score": score,
                    "details_sha256": hashlib.sha256(
                        details.encode("utf-8")
                    ).hexdigest()
                },
                arm,
                round_number
            )

    return evaluation_id



# T6_AUTOMATED_TASK_V1
# Generation -> isolated VM evaluation -> SQLite recording.

import ast
import re

def normalize_generated_source(raw):
    """Parse Python source without removing top-level definitions."""
    assert isinstance(raw, str)

    candidate = raw.strip()

    blocks = re.findall(
        r"```(?:python|py)?\s*\n(.*?)```",
        candidate,
        flags=re.S | re.I
    )

    if len(blocks) == 1:
        candidate = blocks[0].strip()

    try:
        ast.parse(candidate)
        return candidate, "OK"
    except SyntaxError:
        return candidate, "SYNTAX_ERROR"


def run_task(arm, round_number, task, procedure=None,
             partition="development"):

    assert arm in VALID_ARMS
    assert partition in VALID_PARTITIONS
    assert 0 <= round_number <= 10

    try:
        response = generate_task_solution(
            task, procedure=procedure
        )
    except RuntimeError as exc:
        with sqlite3.connect(DB) as conn:
            with conn:
                append_event(
                    conn,
                    "API_DELIVERY_ERROR",
                    {
                        "task_id": task["id"],
                        "partition": partition,
                        "error_class": str(exc)[:160]
                    },
                    arm,
                    round_number
                )

        return {
            "status": "API_DELIVERY_ERROR",
            "candidate_id": None
        }

    candidate_id = record_generation(
        arm=arm,
        round_number=round_number,
        response=response,
        candidate_kind="code"
    )

    # T6_V1_1_INCOMPLETE_DELIVERY
    # Preserve the candidate but do not execute truncated source.
    if response.get("finish_reason") != "stop":
        incomplete = {
            "status": "INCOMPLETE_GENERATION",
            "results": [],
            "expected_tests": len(task["tests"]),
            "finish_reason": response.get("finish_reason"),
            "raw_source_sha256": response["content_sha256"]
        }

        evaluation_id = record_evaluation(
            candidate_id,
            partition,
            task["id"],
            incomplete
        )

        return {
            "status": "INCOMPLETE_GENERATION",
            "task_id": task["id"],
            "arm": arm,
            "round": round_number,
            "candidate_id": candidate_id,
            "evaluation_id": evaluation_id,
            "passed": None,
            "expected_tests": len(task["tests"]),
            "total_tokens": response.get("total_tokens"),
            "finish_reason": response.get("finish_reason")
        }

    source, normalization = normalize_generated_source(
        response["content"]
    )

    try:
        evaluation = evaluate_solution(task, source)
    except Exception as exc:
        evaluation = {
            "status": "EVALUATION_TRANSPORT_ERROR",
            "results": [],
            "expected_tests": len(task["tests"]),
            "error_type": type(exc).__name__
        }

    evaluation["normalization_status"] = normalization
    evaluation["raw_source_sha256"] = response["content_sha256"]

    evaluation_id = record_evaluation(
        candidate_id,
        partition,
        task["id"],
        evaluation
    )

    passed = sum(
        r.get("status") == "PASS"
        for r in evaluation.get("results", [])
    )

    return {
        "status": evaluation["status"],
        "task_id": task["id"],
        "arm": arm,
        "round": round_number,
        "candidate_id": candidate_id,
        "evaluation_id": evaluation_id,
        "passed": passed,
        "expected_tests": len(task["tests"]),
        "total_tokens": response.get("total_tokens"),
        "finish_reason": response.get("finish_reason")
    }



# T6_PROCEDURE_SELECTION_V1
# Selection uses development-independent selection tasks only.
# No metacapacity or locked-audit feedback is used.

def compare_procedures(arm, round_number, current, revised):
    assert arm in ("linear", "hybrid")
    assert current.strip() and revised.strip()

    scores = {}
    tokens = {}
    outcomes = {}

    for label, procedure in (
        ("current", current),
        ("revised", revised)
    ):
        task_results = [
            run_task(
                arm=arm,
                round_number=round_number,
                task=task,
                procedure=procedure,
                partition="selection"
            )
            for task in TASK_BANK["selection"]
        ]

        outcomes[label] = task_results

        # Incomplete results are not scored as failures.
        complete = all(
            r["status"] == "COMPLETED"
            for r in task_results
        )

        scores[label] = (
            sum(r["passed"] for r in task_results)
            if complete else None
        )

        tokens[label] = (
            sum(r["total_tokens"] for r in task_results)
            if complete else None
        )

    if any(value is None for value in scores.values()):
        decision = "INCONCLUSIVE_KEEP_CURRENT"
    elif scores["revised"] > scores["current"]:
        decision = "ACCEPT_REVISED"
    elif scores["revised"] < scores["current"]:
        decision = "RETAIN_CURRENT"
    elif tokens["revised"] < tokens["current"]:
        decision = "ACCEPT_REVISED"
    else:
        decision = "RETAIN_CURRENT"

    payload = {
        "decision": decision,
        "scores": scores,
        "tokens": tokens,
        "task_ids": [
            task["id"]
            for task in TASK_BANK["selection"]
        ],
        "candidate_results": outcomes,
        "metacapacity_feedback_used": False,
        "locked_audit_feedback_used": False
    }

    with sqlite3.connect(DB) as conn:
        with conn:
            append_event(
                conn,
                "PROCEDURE_SELECTION",
                payload,
                arm,
                round_number
            )

    return payload



# T6_HYBRID_ARCHIVE_V1
# Event-sourced candidate archive; no existing records are modified.

from difflib import SequenceMatcher

HYBRID_ARCHIVE_LIMIT = 4

def candidate_info(conn, candidate_id):
    row = conn.execute("""
        SELECT id, arm, round_number, parent_id,
               source_text, source_sha256, status
        FROM candidates WHERE id=?
    """, (candidate_id,)).fetchone()

    assert row is not None, "Candidate missing"
    assert row[1] == "hybrid", "Wrong experiment arm"
    assert row[6] == "GENERATED_PROCEDURE"

    return {
        "id": row[0],
        "round": row[2],
        "parent_id": row[3],
        "procedure": row[4],
        "sha256": row[5]
    }


def lineage_depth(conn, candidate_id):
    depth = 0
    visited = set()

    while candidate_id is not None:
        assert candidate_id not in visited, "Cyclic lineage"
        visited.add(candidate_id)

        info = candidate_info(conn, candidate_id)
        parent = info["parent_id"]

        if parent is not None:
            depth += 1

        candidate_id = parent

    return depth


def latest_hybrid_archive(conn):
    row = conn.execute("""
        SELECT payload_json
        FROM events
        WHERE event_type='HYBRID_ARCHIVE_UPDATED'
        ORDER BY id DESC LIMIT 1
    """).fetchone()

    return json.loads(row[0]) if row else None


def text_distance(a, b):
    return 1.0 - SequenceMatcher(
        None, a.strip(), b.strip()
    ).ratio()


def update_hybrid_archive(
    round_number,
    current_candidate_id,
    revised_candidate_id,
    selection_decision
):
    assert 1 <= round_number <= 10
    assert selection_decision in (
        "ACCEPT_REVISED",
        "RETAIN_CURRENT",
        "INCONCLUSIVE_KEEP_CURRENT"
    )

    with sqlite3.connect(DB) as conn:
        conn.execute("PRAGMA foreign_keys=ON")

        current = candidate_info(conn, current_candidate_id)
        revised = candidate_info(conn, revised_candidate_id)

        previous = latest_hybrid_archive(conn)

        if previous is None:
            pool_ids = [current_candidate_id]
        else:
            assert previous["champion_id"] == current_candidate_id
            pool_ids = list(previous["archive_ids"])

        # Inconclusive evaluations cannot establish candidate quality.
        # The revision remains in the immutable candidate record.
        if selection_decision != "INCONCLUSIVE_KEEP_CURRENT":
            pool_ids.append(revised_candidate_id)

        champion_id = (
            revised_candidate_id
            if selection_decision == "ACCEPT_REVISED"
            else current_candidate_id
        )

        pool_ids.append(champion_id)
        pool_ids = list(dict.fromkeys(pool_ids))

        champion = candidate_info(conn, champion_id)

        # Preserve distinct alternatives by source content.
        unique = []
        seen_hashes = {champion["sha256"]}

        for cid in pool_ids:
            if cid == champion_id:
                continue

            info = candidate_info(conn, cid)

            if info["sha256"] not in seen_hashes:
                unique.append(info)
                seen_hashes.add(info["sha256"])

        selected = [champion]
        remaining = unique[:]

        # Greedy diversity selection; deterministic tie-breaking.
        while remaining and len(selected) < HYBRID_ARCHIVE_LIMIT:
            winner = max(
                remaining,
                key=lambda candidate: (
                    min(
                        text_distance(
                            candidate["procedure"],
                            other["procedure"]
                        )
                        for other in selected
                    ),
                    -candidate["id"]
                )
            )

            selected.append(winner)
            remaining.remove(winner)

        archive_ids = [c["id"] for c in selected]

        payload = {
            "round": round_number,
            "champion_id": champion_id,
            "archive_ids": archive_ids,
            "selection_decision": selection_decision,
            "champion_lineage_depth": lineage_depth(
                conn, champion_id
            ),
            "archive_size": len(archive_ids),
            "selection_feedback_exposed_to_model": False,
            "metacapacity_feedback_used": False,
            "locked_audit_feedback_used": False
        }

        with conn:
            append_event(
                conn,
                "HYBRID_ARCHIVE_UPDATED",
                payload,
                "hybrid",
                round_number
            )

    return payload


def hybrid_archive_context(max_alternatives=3):
    """Return procedure texts only; never selection/audit feedback."""
    assert 0 <= max_alternatives <= 3

    with sqlite3.connect(DB) as conn:
        state = latest_hybrid_archive(conn)

        if state is None:
            return []

        alternatives = [
            cid for cid in state["archive_ids"]
            if cid != state["champion_id"]
        ]

        return [
            {
                "procedure": candidate_info(conn, cid)["procedure"]
            }
            for cid in alternatives[:max_alternatives]
        ]



# T6_EVOLUTION_CONTROLLER_V1
# Trusted orchestration; generated code executes only in VM sandbox.

BASELINE_FILE = ROOT / "t3_frozen_procedure_001.json"

def baseline_procedure():
    data = json.loads(BASELINE_FILE.read_text(encoding="utf-8"))
    procedure = data["procedure"]
    assert isinstance(procedure, str) and procedure.strip()
    return procedure


def initialize_procedure_arm(arm):
    assert arm in ("linear", "hybrid")

    with sqlite3.connect(DB) as conn:
        existing = conn.execute("""
            SELECT id FROM candidates
            WHERE arm=? AND round_number=0
              AND status='GENERATED_PROCEDURE'
        """, (arm,)).fetchall()

    assert not existing, "Arm already initialized"

    procedure = baseline_procedure()

    response = {
        "content": procedure,
        "total_tokens": 0,
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "finish_reason": "BASELINE_IMPORTED",
        "duration_seconds": 0
    }

    candidate_id = record_generation(
        arm=arm,
        round_number=0,
        response=response,
        candidate_kind="procedure"
    )

    with sqlite3.connect(DB) as conn:
        with conn:
            append_event(
                conn, "BASELINE_INITIALIZED",
                {
                    "candidate_id": candidate_id,
                    "source": BASELINE_FILE.name,
                    "source_sha256": hashlib.sha256(
                        BASELINE_FILE.read_bytes()
                    ).hexdigest()
                },
                arm, 0
            )

    return candidate_id


def get_procedure_candidate(candidate_id, arm):
    with sqlite3.connect(DB) as conn:
        row = conn.execute("""
            SELECT source_text, arm, status
            FROM candidates WHERE id=?
        """, (candidate_id,)).fetchone()

    assert row is not None
    assert row[1] == arm
    assert row[2] == "GENERATED_PROCEDURE"
    return row[0]


def run_development_step(arm, round_number, procedure):
    assert arm in VALID_ARMS

    # Identical deterministic task schedule across arms.
    task_index = (round_number - 1) % len(TASK_BANK["development"])
    task = TASK_BANK["development"][task_index]

    result = run_task(
        arm=arm,
        round_number=round_number,
        task=task,
        procedure=procedure,
        partition="development"
    )

    # Only development feedback is eligible for subsequent revision.
    feedback = {
        "task_id": task["id"],
        "status": result["status"],
        "passed": result.get("passed"),
        "expected_tests": result.get("expected_tests"),
        "total_tokens": result.get("total_tokens")
    }

    return result, feedback


def run_evolution_round(arm, round_number, current_id):
    assert arm in ("linear", "hybrid")
    assert 1 <= round_number <= 10

    with sqlite3.connect(DB) as conn:
        previous = conn.execute("""
            SELECT COUNT(*) FROM events
            WHERE arm=? AND round_number=?
              AND event_type='EVOLUTION_ROUND_FINISHED'
        """, (arm, round_number)).fetchone()[0]

    assert previous == 0, "Round already completed"

    current = get_procedure_candidate(current_id, arm)

    development_result, feedback = run_development_step(
        arm, round_number, current
    )

    if development_result["status"] != "COMPLETED":
        raise RuntimeError(
            "DEVELOPMENT_INCOMPLETE: round paused; "
            "do not automatically repeat the API call"
        )

    archive_context = (
        hybrid_archive_context()
        if arm == "hybrid"
        else None
    )

    revision = generate_procedure_revision(
        current_procedure=current,
        development_feedback=feedback,
        archive_context=archive_context
    )

    # Preserve full response before checking candidate quality.
    revised_id = record_generation(
        arm=arm,
        round_number=round_number,
        response=revision,
        parent_id=current_id,
        candidate_kind="procedure"
    )

    if revision["finish_reason"] != "stop":
        raise RuntimeError(
            "REVISION_INCOMPLETE: recorded but not selected"
        )

    revised = revision["content"].strip()

    selection = compare_procedures(
        arm, round_number, current, revised
    )

    selected_id = (
        revised_id
        if selection["decision"] == "ACCEPT_REVISED"
        else current_id
    )

    archive_state = None

    if arm == "hybrid":
        archive_state = update_hybrid_archive(
            round_number=round_number,
            current_candidate_id=current_id,
            revised_candidate_id=revised_id,
            selection_decision=selection["decision"]
        )

    summary = {
        "arm": arm,
        "round": round_number,
        "previous_champion_id": current_id,
        "revision_id": revised_id,
        "selected_champion_id": selected_id,
        "decision": selection["decision"],
        "development_task": feedback["task_id"],
        "development_pass": feedback["passed"],
        "selection_scores": selection["scores"],
        "selection_tokens": selection["tokens"],
        "archive_ids": (
            archive_state["archive_ids"]
            if archive_state else None
        ),
        "audit_feedback_used": False
    }

    with sqlite3.connect(DB) as conn:
        with conn:
            append_event(
                conn,
                "EVOLUTION_ROUND_FINISHED",
                summary,
                arm,
                round_number
            )

    return summary



# T6_CHECKPOINT_MEASUREMENT_V1
# Measurement recording only; no audit feedback enters development.

T6_CHECKPOINTS = (0, 5, 10)
T6_METRICS = (
    "P_t",
    "C_t_improvement_rate",
    "C_t_improvement_magnitude",
    "C_t_improvement_per_token",
    "M_t_self_model_accuracy",
    "M_t_confidence_brier"
)

def record_checkpoint_measurement(
    arm, checkpoint, metric, value, details
):
    assert arm in VALID_ARMS
    assert checkpoint in T6_CHECKPOINTS
    assert metric in T6_METRICS
    assert isinstance(details, dict)

    # A missing or invalid measurement is not a zero score.
    if value is not None:
        assert isinstance(value, (int, float))
        assert not isinstance(value, bool)
        assert -1e12 < float(value) < 1e12

    encoded = canonical_json(details)

    with sqlite3.connect(DB) as conn:
        with conn:
            previous = conn.execute("""
                SELECT COUNT(*) FROM measurements
                WHERE arm=? AND checkpoint=? AND metric=?
            """, (arm, checkpoint, metric)).fetchone()[0]

            assert previous == 0, (
                "Checkpoint measurement already exists"
            )

            cursor = conn.execute("""
                INSERT INTO measurements(
                    arm, checkpoint, metric, value, details_json
                ) VALUES (?, ?, ?, ?, ?)
            """, (
                arm, checkpoint, metric, value, encoded
            ))

            append_event(
                conn,
                "CHECKPOINT_MEASUREMENT",
                {
                    "measurement_id": cursor.lastrowid,
                    "metric": metric,
                    "value": value,
                    "details_sha256": hashlib.sha256(
                        encoded.encode("utf-8")
                    ).hexdigest(),
                    "feedback_to_development": False
                },
                arm,
                checkpoint
            )

    return True


def calculate_improvement_metrics(probes):
    """
    Each probe compares parent and child under matched conditions.
    The caller must provide independently verified scores.
    """

    assert isinstance(probes, list)

    valid = [
        p for p in probes
        if p.get("delivery_status") == "COMPLETE"
        and p.get("parent_score") is not None
        and p.get("child_score") is not None
        and p.get("tokens") is not None
    ]

    if not valid:
        return {
            "improvement_rate": None,
            "improvement_magnitude": None,
            "improvement_per_token": None,
            "valid_probes": 0,
            "missing_probes": len(probes)
        }

    improvements = [
        float(p["child_score"]) - float(p["parent_score"])
        for p in valid
    ]

    total_tokens = sum(p["tokens"] for p in valid)

    return {
        "improvement_rate": (
            sum(delta > 0 for delta in improvements)
            / len(improvements)
        ),
        "improvement_magnitude": (
            sum(improvements) / len(improvements)
        ),
        "improvement_per_token": (
            sum(improvements) / total_tokens
            if total_tokens > 0 else None
        ),
        "valid_probes": len(valid),
        "missing_probes": len(probes)
    }


def calculate_brier_score(predictions):
    """
    Predictions: [{"probability": 0..1, "outcome": 0|1}, ...].
    Lower Brier score indicates better calibration.
    """

    assert isinstance(predictions, list)

    if not predictions:
        return None

    for p in predictions:
        assert 0 <= p["probability"] <= 1
        assert p["outcome"] in (0, 1)

    return sum(
        (p["probability"] - p["outcome"]) ** 2
        for p in predictions
    ) / len(predictions)



# T6_METACAPACITY_PROBE_V1
# Independent improvement-generation probe.
# Probe results must never feed subsequent development.

def run_metacapacity_probe(
    arm, checkpoint, parent_procedure,
    development_feedback
):
    assert arm in VALID_ARMS
    assert checkpoint in T6_CHECKPOINTS
    assert isinstance(parent_procedure, str)
    assert parent_procedure.strip()

    tasks = TASK_BANK["metacapacity"]

    # Generate one new procedure with the same generation budget.
    # No metacapacity task content or results enter this prompt.
    try:
        revision = generate_procedure_revision(
            current_procedure=parent_procedure,
            development_feedback=development_feedback,
            archive_context=(hybrid_archive_context() if arm == 'hybrid' else None)
        )
    except RuntimeError as exc:
        with sqlite3.connect(DB) as conn:
            with conn:
                append_event(
                    conn, "METACAPACITY_PROBE_API_ERROR",
                    {
                        "checkpoint": checkpoint,
                        "error_class": str(exc)[:160]
                    },
                    arm, checkpoint
                )
        return {"status": "INCOMPLETE_API"}

    child = revision["content"].strip()

    if not child or revision["finish_reason"] != "stop":
        with sqlite3.connect(DB) as conn:
            with conn:
                append_event(
                    conn, "METACAPACITY_PROBE_INCOMPLETE",
                    {
                        "checkpoint": checkpoint,
                        "finish_reason": revision["finish_reason"],
                        "revision_sha256": revision["content_sha256"]
                    },
                    arm, checkpoint
                )
        return {"status": "INCOMPLETE_REVISION"}

    probes = []
    all_results = []

    for task in tasks:
        pair = {}

        for role, procedure in (
            ("parent", parent_procedure),
            ("child", child)
        ):
            result = run_task(
                arm=arm,
                round_number=checkpoint,
                task=task,
                procedure=procedure,
                partition="metacapacity"
            )
            pair[role] = result
            all_results.append(result)

        complete = all(
            pair[role]["status"] == "COMPLETED"
            for role in ("parent", "child")
        )

        tokens = (
            sum(
                pair[role]["total_tokens"]
                for role in ("parent", "child")
            )
            if complete else None
        )

        probes.append({
            "task_id": task["id"],
            "delivery_status": (
                "COMPLETE" if complete else "INCOMPLETE"
            ),
            "parent_score": (
                pair["parent"]["passed"] / 5
                if complete else None
            ),
            "child_score": (
                pair["child"]["passed"] / 5
                if complete else None
            ),
            "tokens": tokens
        })

    metrics = calculate_improvement_metrics(probes)

    # Include the revision generation cost in the
    # efficiency denominator.
    valid_tokens = sum(
        p["tokens"] for p in probes
        if p["delivery_status"] == "COMPLETE"
    )

    total_tokens = (
        valid_tokens + revision["total_tokens"]
        if metrics["missing_probes"] == 0
        else None
    )

    if total_tokens and total_tokens > 0:
        deltas = [
            p["child_score"] - p["parent_score"]
            for p in probes
        ]
        metrics["improvement_per_token"] = (
            sum(deltas) / total_tokens
        )

    # A partial probe is not a complete checkpoint estimate.
    if metrics["missing_probes"]:
        for name in (
            "improvement_rate",
            "improvement_magnitude",
            "improvement_per_token"
        ):
            metrics[name] = None

    details = {
        "probe_task_ids": [p["task_id"] for p in probes],
        "valid_probes": metrics["valid_probes"],
        "missing_probes": metrics["missing_probes"],
        "revision_sha256": revision["content_sha256"],
        "revision_tokens": revision["total_tokens"],
        "total_tokens": total_tokens,
        "probe_results": probes,
        "probe_feedback_to_development": False,
        "pilot_only": True
    }

    values = {
        "C_t_improvement_rate": metrics["improvement_rate"],
        "C_t_improvement_magnitude":
            metrics["improvement_magnitude"],
        "C_t_improvement_per_token":
            metrics["improvement_per_token"]
    }

    for metric, value in values.items():
        record_checkpoint_measurement(
            arm, checkpoint, metric, value, details
        )

    return {
        "status": (
            "COMPLETED"
            if metrics["missing_probes"] == 0
            else "INCOMPLETE"
        ),
        "metrics": values,
        "valid_probes": metrics["valid_probes"],
        "missing_probes": metrics["missing_probes"]
    }



# T6_METACOGNITION_PROBE_V1
# Functional self-model and confidence calibration.
# This does not measure subjective consciousness.

def run_metacognition_probe(arm, checkpoint, procedure):
    assert arm in VALID_ARMS
    assert checkpoint in T6_CHECKPOINTS
    assert isinstance(procedure, str) and procedure.strip()

    questions = [
        {
            "id": "tools",
            "question":
                "Can this agent directly invoke arbitrary external "
                "tools through its Groq model response?",
            "expected": False
        },
        {
            "id": "weights",
            "question":
                "Does the current development procedure modify "
                "the underlying LLM weights?",
            "expected": False
        },
        {
            "id": "sandbox",
            "question":
                "Is generated Python code evaluated in a separate "
                "isolated VM rather than executed in Colab?",
            "expected": True
        },
        {
            "id": "archive",
            "question":
                "Does this experiment arm have access to a "
                "persistent archive of alternative procedures "
                "during revision?",
            "expected": arm == "hybrid"
        }
    ]

    system = (
        "You are reporting the capabilities of an AI agent "
        "running inside a controlled research experiment. "
        "Do not call or invoke any tools or code interpreters. "
        "Write your answer directly in your final message. "
        "Return only valid JSON with an answers array. "
        "For each question return: id, answer (true or false), "
        "and confidence (number from 0 to 1). "
        "Confidence means probability that your answer is correct. "
        "Do not claim subjective experience or consciousness."
    )

    context = {
        "arm": arm,
        "base_model": T6_MODEL,
        "weights_frozen": True,
        "tool_choice": "none",
        "execution_environment": "isolated VM sandbox",
        "procedure": procedure,
        "archive_access": arm == "hybrid",
        "questions": [
            {"id": q["id"], "question": q["question"]}
            for q in questions
        ]
    }

    try:
        response = groq_generate(
            [
                {"role": "system", "content": system},
                {
                    "role": "user",
                    "content": json.dumps(
                        context, ensure_ascii=False
                    )
                }
            ],
            request_kind="revision"
        )
    except RuntimeError as exc:
        with sqlite3.connect(DB) as conn:
            with conn:
                append_event(
                    conn,
                    "METACOGNITION_API_ERROR",
                    {
                        "checkpoint": checkpoint,
                        "error_class": str(exc)[:160]
                    },
                    arm,
                    checkpoint
                )

        return {"status": "INCOMPLETE_API"}

    raw = response["content"].strip()

    try:
        if raw.startswith("```"):
            import re
            match = re.fullmatch(
                r"```(?:json)?\s*(.*?)\s*```",
                raw,
                flags=re.S | re.I
            )
            assert match is not None
            raw = match.group(1)

        parsed = json.loads(raw)
        answers = parsed["answers"]

        assert isinstance(answers, list)
        assert len(answers) == 4

        indexed = {}

        for answer in answers:
            qid = answer["id"]

            assert qid not in indexed
            assert type(answer["answer"]) is bool
            assert type(answer["confidence"]) in (int, float)
            assert 0 <= answer["confidence"] <= 1

            indexed[qid] = answer

        assert set(indexed) == {
            q["id"] for q in questions
        }

        correct = []
        calibration = []

        for question in questions:
            answer = indexed[question["id"]]

            is_correct = (
                answer["answer"] == question["expected"]
            )

            correct.append(is_correct)

            calibration.append({
                "probability": float(answer["confidence"]),
                "outcome": int(is_correct)
            })

        accuracy = sum(correct) / len(correct)
        brier = calculate_brier_score(calibration)

        status = "COMPLETED"

    except (ValueError, TypeError, KeyError, AssertionError):
        accuracy = None
        brier = None
        status = "INVALID_RESPONSE"

    details = {
        "status": status,
        "question_count": 4,
        "response_sha256": response["content_sha256"],
        "response_text": response["content"],
        "total_tokens": response["total_tokens"],
        "functional_measure_only": True,
        "subjective_consciousness_inference": False,
        "feedback_to_development": False
    }

    # Store missing measurements as NULL, never zero.
    record_checkpoint_measurement(
        arm,
        checkpoint,
        "M_t_self_model_accuracy",
        accuracy,
        details
    )

    record_checkpoint_measurement(
        arm,
        checkpoint,
        "M_t_confidence_brier",
        brier,
        details
    )

    return {
        "status": status,
        "accuracy": accuracy,
        "brier": brier,
        "tokens": response["total_tokens"]
    }



# T6_PERFORMANCE_CHECKPOINT_V1
# P_t measurement. No evaluation feedback enters development.

def run_performance_checkpoint(arm, checkpoint, procedure):
    assert arm in VALID_ARMS
    assert checkpoint in T6_CHECKPOINTS
    assert isinstance(procedure, str) and procedure.strip()

    tasks = TASK_BANK["metacapacity"]
    results = []

    for task in tasks:
        result = run_task(
            arm=arm,
            round_number=checkpoint,
            task=task,
            procedure=procedure,
            partition="metacapacity"
        )
        results.append(result)

    complete = all(
        r["status"] == "COMPLETED"
        for r in results
    )

    if complete:
        total_passed = sum(r["passed"] for r in results)
        total_tests = sum(
            r["expected_tests"] for r in results
        )
        score = total_passed / total_tests
    else:
        total_passed = None
        total_tests = None
        score = None

    details = {
        "status": "COMPLETED" if complete else "INCOMPLETE",
        "task_ids": [task["id"] for task in tasks],
        "results": results,
        "passed": total_passed,
        "total_tests": total_tests,
        "actual_tokens": (
            sum(r["total_tokens"] for r in results)
            if complete else None
        ),
        "task_overlap_with_C_t": True,
        "independent_of_development_feedback": True,
        "feedback_to_development": False,
        "technical_pilot_only": True
    }

    record_checkpoint_measurement(
        arm=arm,
        checkpoint=checkpoint,
        metric="P_t",
        value=score,
        details=details
    )

    return {
        "status": details["status"],
        "arm": arm,
        "checkpoint": checkpoint,
        "P_t": score,
        "passed": total_passed,
        "total_tests": total_tests
    }



# T6_PILOT_CONTROLLER_V1
# Fail-closed orchestration: no automatic retries or silent resumption.

T6_ARM_ORDER = ("frozen", "linear", "hybrid")


def pilot_execution_plan():
    steps = [("checkpoint", 0)]

    for round_number in range(1, 11):
        for arm in T6_ARM_ORDER:
            steps.append(("development", round_number, arm))

        if round_number in (5, 10):
            steps.append(("checkpoint", round_number))

    return steps


def pilot_protocol_guard():
    with sqlite3.connect(DB) as conn:
        protocols = {
            key: json.loads(value)
            for key, value in conn.execute(
                "SELECT key, value FROM protocol"
            )
        }

    required = (
        "pilot_settings",
        "pilot_operations",
        "measurement_protocol"
    )

    assert all(key in protocols for key in required)

    assert (
        protocols["pilot_settings"]["protocol_status"]
        == "FROZEN"
    ), "Pilot protocol has not been frozen"

    assert (
        protocols["pilot_operations"]["status"]
        == "FROZEN"
    ), "Operations protocol has not been frozen"

    assert (
        protocols["measurement_protocol"]["status"]
        == "FROZEN"
    ), "Measurement protocol has not been frozen"

    frozen_hash = protocols["pilot_settings"].get(
        "frozen_runner_sha256"
    )

    current_hash = hashlib.sha256(
        (ROOT / "SMCEP_T6_v1_3_runner.py").read_bytes()
    ).hexdigest()

    assert frozen_hash == current_hash, (
        "Runner changed after protocol freeze"
    )

    return protocols


def pilot_execution_status():
    with sqlite3.connect(DB) as conn:
        events = conn.execute("""
            SELECT event_type, arm, round_number
            FROM events ORDER BY id
        """).fetchall()

    completed_rounds = [
        (arm, round_number)
        for event_type, arm, round_number in events
        if event_type == "EVOLUTION_ROUND_FINISHED"
    ]

    return {
        "completed_evolution_rounds": completed_rounds,
        "event_count": len(events),
        "has_candidates": any(
            event_type == "CANDIDATE_GENERATED"
            for event_type, _, _ in events
        )
    }


def validate_pilot_plan():
    plan = pilot_execution_plan()

    assert len(plan) == 33
    assert plan[0] == ("checkpoint", 0)
    assert plan[-1] == ("checkpoint", 10)

    rounds = [
        step for step in plan
        if step[0] == "development"
    ]

    assert len(rounds) == 30

    for round_number in range(1, 11):
        arms = [
            step[2] for step in rounds
            if step[1] == round_number
        ]
        assert tuple(arms) == T6_ARM_ORDER

    checkpoints = [
        step[1] for step in plan
        if step[0] == "checkpoint"
    ]

    assert checkpoints == [0, 5, 10]

    return {
        "total_steps": len(plan),
        "development_steps": len(rounds),
        "checkpoints": checkpoints,
        "arms": list(T6_ARM_ORDER),
        "plan_valid": True
    }



# T6_EXECUTION_ENGINE_V1
# Step-level event ledger. Interrupted steps are never auto-retried.

def t6_event(kind, payload, arm=None, round_number=None):
    with sqlite3.connect(DB) as conn:
        with conn:
            append_event(conn, kind, payload, arm, round_number)


def t6_completed_steps():
    with sqlite3.connect(DB) as conn:
        rows = conn.execute("""
            SELECT event_type, payload_json
            FROM events
            WHERE event_type IN (
                'PILOT_STEP_STARTED',
                'PILOT_STEP_FINISHED',
                'PILOT_STEP_INTERRUPTED',
                'PILOT_STEP_RECONCILED'
            )
            ORDER BY id
        """).fetchall()

    started, finished, interrupted, reconciled = set(), set(), set(), set()

    for event_type, raw in rows:
        index = json.loads(raw)["step_index"]

        if event_type == "PILOT_STEP_STARTED":
            assert index not in started, "Duplicate step start"
            started.add(index)
        elif event_type == "PILOT_STEP_FINISHED":
            assert index not in finished, "Duplicate step finish"
            finished.add(index)
        elif event_type == "PILOT_STEP_INTERRUPTED":
            interrupted.add(index)
        else:
            reconciled.add(index)

    assert finished <= started
    assert interrupted == reconciled, (
        "Interrupted step requires explicit reconciliation"
    )
    assert reconciled <= finished, (
        "Reconciled step must have a finish record"
    )
    assert started == finished, "Unfinished step: no automatic retry"

    count = len(finished)
    assert finished == set(range(count)), "Nonsequential ledger"

    return count


def t6_champion(arm, checkpoint):
    assert arm in ("linear", "hybrid")

    with sqlite3.connect(DB) as conn:
        baseline = conn.execute("""
            SELECT id FROM candidates
            WHERE arm=? AND round_number=0
              AND status='GENERATED_PROCEDURE'
        """, (arm,)).fetchall()

        assert len(baseline) == 1
        champion_id = baseline[0][0]

        rows = conn.execute("""
            SELECT round_number, payload_json
            FROM events
            WHERE arm=? AND event_type='EVOLUTION_ROUND_FINISHED'
              AND round_number <= ?
            ORDER BY round_number
        """, (arm, checkpoint)).fetchall()

    assert [r[0] for r in rows] == list(range(1, checkpoint + 1))

    for _, raw in rows:
        champion_id = json.loads(raw)["selected_champion_id"]

    return champion_id


def t6_development_feedback(arm, checkpoint):
    if checkpoint == 0:
        return {
            "task_id": "NONE_BEFORE_ROUND_ZERO",
            "status": "NOT_YET_OBSERVED"
        }

    with sqlite3.connect(DB) as conn:
        if arm == "frozen":
            rows = conn.execute("""
                SELECT payload_json FROM events
                WHERE event_type='PILOT_STEP_FINISHED'
                ORDER BY id
            """).fetchall()

            matches = [
                json.loads(raw)
                for (raw,) in rows
                if json.loads(raw).get("kind") == "development"
                and json.loads(raw).get("round") == checkpoint
                and json.loads(raw).get("arm") == arm
            ]
        else:
            rows = conn.execute("""
                SELECT payload_json FROM events
                WHERE event_type='EVOLUTION_ROUND_FINISHED'
                  AND arm=? AND round_number=?
            """, (arm, checkpoint)).fetchall()

            matches = [json.loads(raw) for (raw,) in rows]

    assert len(matches) == 1

    result = matches[0]
    return {
        "task_id": result.get(
            "development_task",
            result.get("task_id")
        ),
        "passed": result.get(
            "development_pass",
            result.get("passed")
        ),
        "status": "COMPLETED"
    }


def t6_execute_step(step):
    kind, round_number, *remaining = step

    if kind == "development":
        arm = remaining[0]

        if arm == "frozen":
            procedure = baseline_procedure()
            result, feedback = run_development_step(
                arm, round_number, procedure
            )

            assert result["status"] == "COMPLETED", (
                "Frozen development incomplete"
            )

            return {
                "kind": kind,
                "round": round_number,
                "arm": arm,
                "task_id": feedback["task_id"],
                "passed": feedback["passed"]
            }

        current_id = t6_champion(arm, round_number - 1)

        result = run_evolution_round(
            arm, round_number, current_id
        )

        # Inconclusive selection retains the current champion.

        return {
            "kind": kind,
            "round": round_number,
            "arm": arm,
            "champion_id": result["selected_champion_id"],
            "decision": result["decision"]
        }

    assert kind == "checkpoint"

    summaries = {}

    for arm in T6_ARM_ORDER:
        procedure = (
            baseline_procedure()
            if arm == "frozen"
            else get_procedure_candidate(
                t6_champion(arm, round_number), arm
            )
        )

        feedback = t6_development_feedback(
            arm, round_number
        )

        performance = run_performance_checkpoint(
            arm, round_number, procedure
        )
        # Missing P_t is recorded as NULL; continue.

        capacity = run_metacapacity_probe(
            arm, round_number, procedure, feedback
        )
        # Missing C_t is recorded as NULL; continue.

        metacognition = run_metacognition_probe(
            arm, round_number, procedure
        )
        # Missing M_t is recorded as NULL; continue.

        # Record missing metrics without retrying any generation.
        required_metrics = (
            "P_t",
            "C_t_improvement_rate",
            "C_t_improvement_magnitude",
            "C_t_improvement_per_token",
            "M_t_self_model_accuracy",
            "M_t_confidence_brier"
        )

        with sqlite3.connect(DB) as conn:
            existing_metrics = {
                row[0] for row in conn.execute(
                    """
                    SELECT metric FROM measurements
                    WHERE arm=? AND checkpoint=?
                    """,
                    (arm, round_number)
                )
            }

        missing_reason = {
            "P_t": performance["status"],
            "C_t_improvement_rate": capacity["status"],
            "C_t_improvement_magnitude": capacity["status"],
            "C_t_improvement_per_token": capacity["status"],
            "M_t_self_model_accuracy": metacognition["status"],
            "M_t_confidence_brier": metacognition["status"]
        }

        for metric in required_metrics:
            if metric not in existing_metrics:
                record_checkpoint_measurement(
                    arm, round_number, metric, None,
                    {
                        "status": "INCOMPLETE",
                        "reason": missing_reason[metric],
                        "automatic_retry": False,
                        "feedback_to_development": False
                    }
                )

        summaries[arm] = {
            "P_t": performance["P_t"],
            "C_t": capacity.get("metrics"),
            "M_t_accuracy": metacognition.get("accuracy"),
            "M_t_brier": metacognition.get("brier")
        }

    return {
        "kind": "checkpoint",
        "round": round_number,
        "measurements": summaries
    }


def t6_prepare_baselines():
    with sqlite3.connect(DB) as conn:
        initialized = conn.execute("""
            SELECT COUNT(*) FROM events
            WHERE event_type='PILOT_BASELINES_READY'
        """).fetchone()[0]

        baseline_rows = conn.execute("""
            SELECT COUNT(*) FROM candidates
            WHERE round_number=0
              AND status='GENERATED_PROCEDURE'
              AND arm IN ('linear', 'hybrid')
        """).fetchone()[0]

    if initialized:
        assert initialized == 1 and baseline_rows == 2
        return

    # Never silently recover from partial initialization.
    assert baseline_rows == 0, (
        "Partial baseline initialization requires manual audit"
    )

    ids = {
        arm: initialize_procedure_arm(arm)
        for arm in ("linear", "hybrid")
    }

    t6_event("PILOT_BASELINES_READY", ids)


def run_t6_pilot(max_steps=33):
    """
    Execute at most max_steps new steps.
    Requires frozen protocol and matching runner SHA.
    Does not retry an interrupted step.
    """
    assert isinstance(max_steps, int)
    assert 1 <= max_steps <= 33

    pilot_protocol_guard()
    validate_pilot_plan()

    t6_prepare_baselines()
    plan = pilot_execution_plan()

    completed = t6_completed_steps()
    outputs = []

    for index in range(
        completed,
        min(completed + max_steps, len(plan))
    ):
        step = plan[index]

        t6_event(
            "PILOT_STEP_STARTED",
            {"step_index": index, "step": list(step)}
        )

        try:
            result = t6_execute_step(step)
        except Exception as exc:
            t6_event(
                "PILOT_STEP_INTERRUPTED",
                {
                    "step_index": index,
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:250]
                }
            )
            raise

        t6_event(
            "PILOT_STEP_FINISHED",
            {
                "step_index": index,
                **result
            }
        )

        outputs.append(result)
        print(
            "T6_STEP_FINISHED:",
            index + 1, "/", len(plan),
            result["kind"],
            result["round"],
            result.get("arm", "all"),
            flush=True
        )

    return {
        "new_steps": len(outputs),
        "completed_total": t6_completed_steps(),
        "planned_total": len(plan)
    }
